#!/bin/bash
echo "tv list:"
list=`cat tvedu.list|cut -d " " -f1`
echo "$list"
echo "please type the tv code"
echo -n "tv:"
read tv
tv=`grep "$tv" tvedu.list |cut -d " " -f2`
echo "you are going to play tv:$tv"
mplayer $tv 
