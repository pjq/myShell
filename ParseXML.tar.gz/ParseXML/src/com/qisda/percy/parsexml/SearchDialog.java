package com.qisda.percy.parsexml;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnKeyListener;
import android.widget.*;
import android.view.*;
import android.view.KeyEvent.*;
import android.view.KeyEvent;

public class SearchDialog extends Activity implements OnClickListener,
		OnKeyListener {
	private AutoCompleteTextView inputCity;
	private ImageButton searchButton;
	public static final String WEATHERDATA = "WeatherData";

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.searchdialog2);

		// inputCity = (EditText) findViewById(R.id.searchDialogInput2);
		searchButton = (ImageButton) findViewById(R.id.searchDialogButton);
		ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
				android.R.layout.simple_dropdown_item_1line, CITYNAMES);
		inputCity = (AutoCompleteTextView) findViewById(R.id.searchDialogInput2);
		inputCity.setAdapter(adapter);
		inputCity.setOnKeyListener(this);
		// inputCity.setFocusable(true);
		searchButton.setOnClickListener(this);

	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.searchDialogButton:
			String cityName = inputCity.getText().toString();
			// make changes. All objects are from android.context.Context
			SharedPreferences settings = PreferenceManager
			.getDefaultSharedPreferences(this);
			SharedPreferences.Editor editor = settings.edit();
			editor.putString("city2", cityName);
			editor.putBoolean("searchButtonClicked", true);
			// Don't forget to commit your edits!!!
			editor.commit();
			/*
			 * Intent intent = new Intent(); intent.setClass(SearchDialog.this,
			 * parsexml.class); startActivity(intent);
			 */
			
			SearchDialog.this.finish();
			break;

		case R.id.searchDialogInput2:

			break;
		default:
			break;
		}
	}

	@Override
	public boolean onKey(View v, int keyCode, KeyEvent event) {
		// super.onKey(v, keyCode, event);
		switch (keyCode) {
		case KeyEvent.KEYCODE_ENTER:
			String cityName = inputCity.getText().toString();
			// make changes. All objects are from android.context.Context
			// SharedPreferences settings = getSharedPreferences(WEATHERDATA,
			// 0);
			SharedPreferences settings = PreferenceManager
					.getDefaultSharedPreferences(this);
			SharedPreferences.Editor editor = settings.edit();
			editor.putString("city2", cityName);
			editor.putBoolean("searchButtonClicked", true);
			// Don't forget to commit your edits!!!
			editor.commit();
			/*
			 * Intent intent = new Intent(); intent.setClass(SearchDialog.this,
			 * parsexml.class); startActivity(intent);
			 */

			SearchDialog.this.finish();
			return true;
			// break;

		default:
			break;

		}
		return false;
	}

	static final String[] CITYNAMES = new String[] { "suzhou", "shanghai",
			"wuxi", "nanjing", "wuchang", "beijing", "nanchang","wuhang","changzhou","xuzhou","kunshan" };
}
