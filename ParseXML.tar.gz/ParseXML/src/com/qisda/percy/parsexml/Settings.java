package com.qisda.percy.parsexml;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.*;
import android.preference.Preference.OnPreferenceChangeListener;
import android.view.View;
import android.view.KeyEvent.*;
import android.view.KeyEvent;

public class Settings extends PreferenceActivity {

	private int BECITY1 = 1;
	private int BECITY2 = 2;

	private EditTextPreference city1;
	private EditTextPreference city2;
	private PreferenceScreen root;

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setPreferenceScreen(createPreferenceScreen());

	}

	public void onStart() {
		super.onStart();
	}

	public void onResume() {
		super.onResume();
	}

	@Override
	public void onPause() {
		super.onPause();

	}

	@Override
	public void onStop() {
		super.onStop();

	}

	@Override
	public void onDestroy() {
		super.onDestroy();

	}

	@Override
	public void onRestart() {
		super.onDestroy();

	}

	public PreferenceScreen createPreferenceScreen() {
		this.root = getPreferenceManager().createPreferenceScreen(this);

		this.root.setTitle("Settings");

		this.city1 = new EditTextPreference(this);
		this.city1.setKey("city1");
		this.city1.setTitle("City1");
		this.city1.setDialogTitle("City1:");
		this.city1.getEditText().setOnKeyListener(new View.OnKeyListener() {
			public boolean onKey(View v, int keyCode, KeyEvent keyEvent) {
				updateDisplaySettings(BECITY1);
				switch (keyCode) {
				case KeyEvent.KEYCODE_ENTER:
					return true;
				default:
					break;

				}
				return false;
			}
		});

		this.city2 = new EditTextPreference(this);
		this.city2.setKey("city2");
		this.city2.setTitle("City2");
		this.city2.setDialogTitle("City2:");
		this.city2.getEditText().setOnKeyListener(new View.OnKeyListener() {
			public boolean onKey(View v, int keyCode, KeyEvent keyEvent) {
				updateDisplaySettings(BECITY2);
				switch (keyCode) {
				case KeyEvent.KEYCODE_ENTER:
					return true;
				default:
					break;

				}
				return false;
			}
		});

		this.root.addPreference(this.city1);
		this.root.addPreference(this.city2);

		this.city1.setSummary(getPreferences("city1"));
		this.city2.setSummary(getPreferences("city2"));

		return this.root;

	}

	public void updateDisplaySettings(int city) {
		switch (city) {
		case 1:
			this.city1
					.setSummary(this.city1.getEditText().getText().toString());
			break;
		case 2:
			this.city2
					.setSummary(this.city2.getEditText().getText().toString());
			break;
		default:
			break;
		}

	}

	public String getPreferences(String keyCode) {
		SharedPreferences settings = PreferenceManager
				.getDefaultSharedPreferences(this);
		String preferences = settings.getString(keyCode, "Not set!");
		return preferences;
	}

}
