package com.qisda.percy.parsexml;

import com.qisda.percy.parsexml.data.WeatherData;
import com.qisda.percy.parsexml.parsexml.*;
import com.qisda.percy.parsexml.handle.*;

import android.view.*;
import android.view.KeyEvent.*;
import android.view.View.OnKeyListener;
import java.net.URL;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.*;
import android.widget.TextView.OnEditorActionListener;
import org.xml.sax.*;

public class parsexml extends Activity {
	/** Called when the activity is first created. */
	private Button search;
	private EditText inputcityname;
	private TextView displayresult;
	private EditText searchDialogInput;
	private String searchDialogInputCity;
	private String defaultCity = "DefaultCity";
	private ProgressBar progressBar;

	public static final String WEATHERDATA = "WeatherData";

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		search = (Button) findViewById(R.id.search);
		inputcityname = (EditText) findViewById(R.id.inputcityname);
		displayresult = (TextView) findViewById(R.id.displayresult);
		progressBar = (ProgressBar) findViewById(R.id.progressBar);

		inputcityname.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				inputcityname.setText("");
			}

		});

		/*
		 * inputcityname.setOnKeyListener(new View.OnKeyListener(){ public
		 * boolean onKey(View v, int keyCode, KeyEvent event) { if (keyCode ==
		 * android.view.KeyEvent.KEYCODE_ENTER){ search(); } return true; }
		 * 
		 * });
		 */
		/*
		 * inputcityname.setOnTouchListener(new View.OnTouchListener(){ public
		 * boolean onTouch(View v, MotionEvent event) {
		 * inputcityname.setText(""); return true; } });
		 */

		search.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				String cityName = inputcityname.getText().toString();
				search(cityName);
			}
		});
	}

	@Override
	public void onStart() {

		super.onStart();
		// SharedPreferences settings = getSharedPreferences(WEATHERDATA, 0);
		SharedPreferences settings = PreferenceManager
				.getDefaultSharedPreferences(this);
		SharedPreferences.Editor editor = settings.edit();
		editor.putBoolean("searchButtonClicked", false);
		String cityName = settings.getString("city1", "");
		search(cityName);
		editor.commit();

	}

	@Override
	public void onRestart() {
		super.onRestart();

	}

	@Override
	public void onResume() {
		super.onResume();

		// SharedPreferences settings =
		// getSharedPreferences(Settings.PREFERENCESFILE, 0);
		SharedPreferences settings = PreferenceManager
				.getDefaultSharedPreferences(this);

		String cityName = settings.getString("city2", "");
		boolean searchButtonClicked = settings.getBoolean(
				"searchButtonClicked", false);
		if (true == searchButtonClicked) {
			progressBar.setVisibility(0);
			search(cityName);
		}

	}

	
	@Override
	public void onPause() {
		super.onPause();

	}

	@Override
	public void onStop() {
		super.onStop();

	}

	@Override
	public void onDestroy() {
		super.onDestroy();

	}

	public void search(String city) {
		try {
			// String cityName = inputcityname.getText().toString();

			// progressBar.startAnimation(null);
			/*
			 * VISIBLE:0 INVISIBLE:4 GONE:8
			 */

			String cityName = city;
			String queryString = "http://www.google.com/ig/api?weather="
					+ cityName;
			// String queryString = "http://10.85.40.42/suzhou.xml";
			URL url = new URL(queryString.replace(" ", "%20"));

			SAXParserFactory spf = SAXParserFactory.newInstance();
			SAXParser sp = spf.newSAXParser();

			XMLReader xr = sp.getXMLReader();

			HandleParseXML handle = new HandleParseXML();
			xr.setContentHandler(handle);

			// Uri uri = Uri.parse("http://10.85.40.42/suzhou.xml");
			// Intent it = new Intent(Intent.ACTION_VIEW, uri);
			// startActivity(it);

			xr.parse(new InputSource(url.openStream()));

			WeatherData weatherData = handle.getWeatherData();

			// displayresult.setText("城市:"+weatherData.getForecastInformationData().getCity()+'\n');
			displayresult.setText("城市:"
					+ weatherData.getForecastInformationData().getPostalCode()
					+ '\n');
			displayresult.append("时间:"
					+ weatherData.getForecastInformationData()
							.getCurrentDateTime() + '\n');
			// displayresult.append("日期"+weatherData.getForecastInformationData().getForecastDate()+'\n');

			// displayresult.append(weatherData.getForecastInformationData().getUnitSystem()+'\n');

			displayresult.append("天气:"
					+ weatherData.getCurrentConditionsData().getCondition()
					+ '\n');
			displayresult.append("湿度:"
					+ weatherData.getCurrentConditionsData().getHumidity()
					+ '\n');
			displayresult.append("显示图像:"
					+ weatherData.getCurrentConditionsData().getIcon() + '\n');
			displayresult.append("摄氏温度:"
					+ weatherData.getCurrentConditionsData().getTempC() + '\n');
			displayresult.append("华氏温度:"
					+ weatherData.getCurrentConditionsData().getTempF() + '\n');
			displayresult.append(weatherData.getCurrentConditionsData()
					.getWindCondition() + '\n');

			displayresult.append("未来四天天气情况:" + '\n');
			for (int i = 0; i < 4; i++) {

				displayresult.append("******************************" + '\n');
				displayresult.append("时间:"
						+ weatherData.getForecastConditionsData().get(i)
								.getDayOfWeek() + '\n');
				displayresult.append("天气:"
						+ weatherData.getForecastConditionsData().get(i)
								.getCondition() + '\n');
				displayresult.append("温度:"
						+ weatherData.getForecastConditionsData().get(i)
								.getLowTemp()
						+ "~"
						+ weatherData.getForecastConditionsData().get(i)
								.getHighTemp() + " C" + '\n');
				displayresult.append("显示图像:"
						+ weatherData.getForecastConditionsData().get(i)
								.getIcon() + '\n');
			}

			progressBar.setVisibility(4);
			System.out.println("Parse XML finished");
			// displayresult.setText("Parse XML finished".toString());

		} catch (Exception e) {
			// Log.e(DEBUG_TAG, "WeatherQueryError", e);
			Toast.makeText(this, getString(R.string.searchException),
					Toast.LENGTH_SHORT).show();
			progressBar.setVisibility(4);
		}
	}

	private static final int SETTING_ID = Menu.FIRST;
	private static final int SEARCH_ID = Menu.FIRST + 1;
	private static final int ABOUT_ID = Menu.FIRST + 2;

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		super.onCreateOptionsMenu(menu);

		menu.add(0, SETTING_ID, 0, "Setting").setIcon(R.drawable.settings);
		menu.add(0, SEARCH_ID, 0, "Search").setIcon(R.drawable.find);
		menu.add(0, ABOUT_ID, 0, "About").setIcon(R.drawable.about);

		/****
		 * Is this the mechanism to extend with filter effects? Intent intent =
		 * new Intent(null, getIntent().getData());
		 * intent.addCategory(Intent.CATEGORY_ALTERNATIVE);
		 * menu.addIntentOptions( Menu.ALTERNATIVE, 0, new ComponentName(this,
		 * NotesList.class), null, intent, 0, null);
		 *****/
		return true;
	}

	@Override
	public boolean onPrepareOptionsMenu(Menu menu) {
		super.onPrepareOptionsMenu(menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// mPaint.setXfermode(null);
		// mPaint.setAlpha(0xFF);

		switch (item.getItemId()) {
		case SETTING_ID:
			Intent intentSettings = new Intent();
			intentSettings.setClass(parsexml.this, Settings.class);
			// new ColorPickerDialog(this, this, mPaint.getColor()).show();
			startActivity(intentSettings);
			return true;
		case SEARCH_ID:
			Intent intent = new Intent();
			intent.setClass(parsexml.this, SearchDialog.class);
			startActivity(intent);
			/*
			 * LayoutInflater factory = LayoutInflater.from(this); final View
			 * textEntryView = factory.inflate(R.layout.searchdialog, null);
			 * 
			 * 
			 * new AlertDialog.Builder(parsexml.this) //
			 * .setIcon(R.drawable.alert_dialog_icon) //
			 * .setTitle(R.string.alert_dialog_text_entry)
			 * .setView(textEntryView).setPositiveButton("OK", new
			 * DialogInterface.OnClickListener() { public void
			 * onClick(DialogInterface dialog, int whichButton) {
			 * search(SearchDialogData.searchDialogInputCity);
			 * 
			 * } }).setNegativeButton("Cancel", new
			 * DialogInterface.OnClickListener() { public void
			 * onClick(DialogInterface dialog, int whichButton) {
			 * 
			 * } }).create().show();
			 * 
			 * SearchDialogData sd = new SearchDialogData();
			 * SearchDialogData.searchDialogInput = (EditText)
			 * findViewById(R.id.searchDialogInput); // this.searchDialogInput =
			 * // (EditText)findViewById(R.id.searchDialogInput); /*
			 * SearchDialogData.searchDialogInput .setOnKeyListener(new
			 * View.OnKeyListener() { public boolean onKey(View tv, int code,
			 * KeyEvent ke) { SearchDialogData.searchDialogInputCity =
			 * SearchDialogData.searchDialogInput .getText().toString(); return
			 * true; }
			 * 
			 * });
			 */
			/*
			 * SearchDialogData.searchDialogInput .addTextChangedListener(new
			 * TextWatcher() { public void afterTextChanged(Editable s) {
			 * SearchDialogData.searchDialogInputCity =
			 * SearchDialogData.searchDialogInput .getText().toString();
			 * 
			 * }
			 * 
			 * public void beforeTextChanged(CharSequence s, int start, int
			 * count, int after) {
			 * 
			 * }
			 * 
			 * public void onTextChanged(CharSequence s, int start, int before,
			 * int count) {
			 * 
			 * }
			 * 
			 * });
			 */

			return true;
		case ABOUT_ID:
			Toast.makeText(this, getString(R.string.about), Toast.LENGTH_SHORT)
					.show();
			return true;

		}
		return super.onOptionsItemSelected(item);
	}
}

class SearchDialogData {

	public static EditText searchDialogInput;
	public static String searchDialogInputCity;

}