package com.qisda.percy.parsexml.handle;

public class TempConvert {
	
	public static int FToC(int F)
	{
		return (int) ((5.0f / 9.0f) * (F - 32));
	}
	
	public static int CToF(int C)
	{
		return (int) ((9.0f / 5.0f) * C + 32);
	}

}
