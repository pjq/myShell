#########################################################################
# Author: PengJianqing@sina.com
# Created Time: 2008年04月17日 星期四 10时35分31秒
# File Name: p.sh
# Description: 
#########################################################################
#!/bin/bash
file=~/shell/tvedu
cat ${file}/tvedu.list|grep -v "#" |sed 's/ /=/g'|grep -n ""|sed 's/^/CH/g'>${file}/t.list
echo "`cat ${file}/t.list|cut -d "=" -f1`"
read -p "tv channel:" tv
mms=`grep CH${tv}:  ${file}/t.list|cut -d "=" -f2`
echo "you are going to play `grep ${mms} ${file}/t.list|cut -d "=" -f1`"
mplayer ${mms}

