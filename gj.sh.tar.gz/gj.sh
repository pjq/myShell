#!/bin/bash
shutdown -h 22:59 "My Gentoo is going to shutdown.See you next time!~"

